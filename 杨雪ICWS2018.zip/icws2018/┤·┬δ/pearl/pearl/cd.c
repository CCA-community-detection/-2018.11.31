/* Program control */

#define VERBOSE        // Set to print progress updates to stderr

/* Inclusions */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <time.h>
#include <gsl/gsl_rng.h>
#include "readgml.h"

/* Constants */
#define contentLength 200
#define K 30// Number of groups
#define EM_ACC 1e-5    // Required accuracy for EM to terminate
#define OUT_EM_ACC 1e-5
#define NOCONVERGE    // Set to abort if the solution doesn't converge
#define OUTEM_MAXSTEP 50// Maximum number of OUTEM steps before aborting
#define INNEREM_MAXSTEP 20//Maximum number of INNEREM steps before aborting
#define SMALL 2.2250738585072014e-309
#define RESTART 1
/*Globals*/
NETWORK G;        // Struct storing the network
//int contentLength;
double balance;

double *pi;         // Prior parameters (
double **theta;    // Mixing parameters
double eta[K][K];     //  community-topic parameters
double **beta;

double **q;     //the postier of community assignment
double ***t;    // the postier of content cluster assignment

gsl_rng *rng;          // Random number generator

double **oldtheta;
double oldpi[K];

// Function to connect two stirng
/*char *join1(char *a, char *b)
{
    char *c = (char *) malloc(strlen(a) + strlen(b) + 1); //�ֲ���������malloc�����ڴ�
    if (c == NULL) exit (1);
    char *tempc = c; //���׵�ַ������
    while (*a != '\0')
    {
        *c++ = *a++;
    }
    while ((*c++ = *b++) != '\0')
    {
        ;
    }
    //ע�⣬��ʱָ��c�Ѿ�ָ��ƴ��֮����ַ����Ľ�β'\0' !
    return tempc;//����ֵ�Ǿֲ�malloc�����ָ����������ں������ý�����free֮
}*/

/* Function to generate d numbers at random that add up to unity */
void random_unity(int d, double *x)
{
    int k;
    double sum=0.0;

    for (k=0; k<d; k++)
    {
        x[k] = gsl_rng_uniform_pos(rng);
        sum += x[k];
    }
    for (k=0; k<d; k++) x[k] /= sum;
}
/* Function to generate d numbers for beta */

void random_beta(int d, double *x, int r)
{
    int k;
    double sum=0.0;

    for (k=0; k<d; k++)
    {
        if(k == r ) x[k] = gsl_rng_uniform_pos(rng)+100;
        else x[k] = gsl_rng_uniform_pos(rng);

        sum += x[k];
    }
    for (k=0; k<d; k++) x[k] /= sum;
}


// Function to calculate new values of the parameters
double params()
{

    int u,v;
    int i,j;
    int r,s;
    int w ;
    int innerStep;
    double  ***qterm,qlargest;
    double**qsum;
    double* qallsum;
    double temp;
    double numerator , denominator[K];
    double ***tterm , **tsum,largestt;
    double etaterm, etasum[K];
    double betaterm[K][contentLength],betasum[K],bterm;
    double ***oldt,oldeta[K][K],oldbeta[K][contentLength];
    double maxInnerdelta,delta;
    double L;
    double ***lterm , **lsum;

    //Make space for oldt
    oldt = malloc(G.nvertices*sizeof(double**));
    for (u = 0; u < G.nvertices; u++)
    {
        oldt[u] = malloc(K*sizeof(double*));
        for (r = 0; r < K ; r++)
        {
            oldt[u][r] = malloc(K*sizeof(double));
        }
    }

    //Calculate E step,the value of q
    qterm = malloc(sizeof(double**)*G.nvertices);
    qsum=malloc(G.nvertices*sizeof(double*));
    qallsum  = malloc(sizeof(double)*G.nvertices);
    for (i = 0 ; i < G.nvertices ; i++)
    {
        qallsum[i] = 0.0;
        qsum[i] =malloc(K*sizeof(double));
        qterm[i] =malloc(K*sizeof(double*));
        for( r = 0 ; r < K ; r ++)
        {
            qsum[i][r] = 0.0;
            qterm[i][r] =malloc(K*sizeof(double));
            for(s = 0 ; s < K ; s++)
            {
                qterm[i][r][s] = 0.0;
            }
        }
    }

    for( i = 0 ; i < G.nvertices ; i++)
    {
        for(r = 0 ; r < K ; r++)
        {
            if(pi[r] < SMALL) pi[r] = SMALL;
            qsum[i][r] += log(pi[r]);
            for(j = 0 ; j < G.vertex[i].degree ; j++)
            {
                u = G.vertex[i].edge[j].target;
                if(theta[r][u] < SMALL) theta[r][u] = SMALL;
                qsum[i][r] += log(theta[r][u]);
            }
            for(s = 0 ; s <K ; s++)
            {
                for(w = 0 ; w < G.vertex[i].hasContentLength; w++)
                {
                    if(beta[s][G.vertex[i].content[w]] < SMALL) beta[s][G.vertex[i].content[w]] = SMALL;
                    qterm[i][r][s] += balance*log(beta[s][G.vertex[i].content[w]]);
                }
                if(t[i][r][s] < SMALL) t[i][r][s] = SMALL;
                if(eta[r][s]< SMALL) eta[r][s] = SMALL;
                qsum[i][r] += t[i][r][s]*(log(eta[r][s])+qterm[i][r][s]-log(t[i][r][s]));
            }
            if( r == 0 ) qlargest = qsum[i][r];
            else if ( qsum[i][r] > qlargest) qlargest = qsum[i][r];
        }

        // normalize
        for( r= 0 ; r < K ; r++)
        {
            qsum[i][r] = qsum[i][r] - qlargest;
            qallsum[i] += exp(qsum[i][r]);
        }
        for(r = 0 ; r < K ; r++)
        {
            q[i][r] = exp(qsum[i][r])/qallsum[i];
            //  printf("qir  %.6f ",q[i][r]);
        }
//   printf("\n");
    }

    // Calculate new values of the pi

    for (r=0; r<K; r++)
    {
        temp = 0.0;
        for(i = 0 ; i < G.nvertices; i++)
        {
            temp+= q[i][r];
        }
        oldpi[r] = pi[r];
        pi[r] = temp/G.nvertices;

        //  printf("pi  %.6f ",pi[r]);
    }

    // Calculate the new values of the thetas
    for(r= 0 ; r < K ; r++)
    {
        denominator[r] = 0.0;
    }
    for(i = 0 ; i < G.nvertices; i++)
    {
        for(r = 0 ; r < K ; r++)
        {
            denominator[r]+= q[i][r]*G.vertex[i].degree;
        }
    }
    for(r= 0 ; r < K ; r++)
    {
        for( j = 0 ; j < G.nvertices ; j++)
        {
            numerator = 0.0;
            for(u = 0 ; u < G.vertex[j].degree ; u++)
            {
                i = G.vertex[j].edge[u].target;
                numerator +=q[i][r];
            }
            oldtheta[r][j] = theta[r][j];
            theta[r][j] = numerator/denominator[r];
            //  printf("theta  %.6f ",theta[r][j]);
        }
        //    printf("\n");
    }

    //inner EM calculte the eta and beta
#ifdef VERBOSE
    fprintf(stderr,"Starting inner EM algorithm...\n");
#endif
    innerStep = 0;
    do
    {

        //calculate the posterior of t
        tterm = malloc(sizeof(double**)*G.nvertices);
      
        for (i = 0 ; i < G.nvertices ; i++)
        {
            tterm[i] = malloc(sizeof(double*)*K);
         
            for( r = 0 ; r < K ; r ++)
            {
             
                tterm[i][r] = malloc(sizeof(double)*K);
                for(s =0 ; s < K ; s++)
                {
                    tterm[i][r][s] = 0.0;
                }
            }
        }
		  tsum = malloc(sizeof(double*)*G.nvertices);
		   for (i = 0 ; i < G.nvertices ; i++)
        {
           
            tsum[i] = malloc(sizeof(double)*K);
            for( r = 0 ; r < K ; r ++)
            {
                tsum[i][r] = 0.0;
               
            }
        }
        for( i =0 ; i < G.nvertices; i++)
        {
            for(r = 0 ; r < K ; r ++)
            {
                for(s = 0 ; s < K ; s++)
                {
                    if(eta[r][s] < SMALL) eta[r][s] =SMALL;
                    tterm[i][r][s] += log(eta[r][s]);
                    for(w= 0 ; w < G.vertex[i].hasContentLength; w++)
                    {
                        if(beta[s][G.vertex[i].content[w]] < SMALL) beta[s][G.vertex[i].content[w]] = SMALL;
                        tterm[i][r][s] += balance*log(beta[s][G.vertex[i].content[w]]);
                    }
                    if(s == 0) largestt = tterm[i][r][s];

                    else if(tterm[i][r][s] > largestt) largestt = tterm[i][r][s];
                }
                // normalize
                for(s = 0 ; s < K ; s++)
                {
                    tterm[i][r][s] -= largestt;
                    tsum[i][r] +=exp(tterm[i][r][s]);
                }
				// printf("%.6f ssssssssssss ",tterm[i][r]);
                for(s = 0 ; s < K ; s++)
                {
                    oldt[i][r][s] = t[i][r][s];
                    t[i][r][s] = exp(tterm[i][r][s])/tsum[i][r];

                 //     printf("%.6f dddddddddddd ",t[i][r][s]);
				//	   printf("%.6f fffffffffff ",tterm[i][r]);
                }
                //  printf("\n");
            }
        }
        // calculate the eta

        for( r = 0 ; r < K ; r++)
        {
            etasum[r] = 0.0;
        }
        for( i = 0 ; i < G.nvertices ; i++)
        {
            for(r = 0 ; r < K ; r++)
            {
                etasum[r] += q[i][r];
            }
        }

        for(r = 0 ; r < K ; r++)
        {
            for(s = 0 ; s < K ; s++)
            {
                etaterm = 0.0;
                for(i = 0 ; i < G.nvertices ; i++)
                {
                    etaterm += q[i][r]*t[i][r][s];
                }
                oldeta[r][s] = eta[r][s];
                eta[r][s] = etaterm/etasum[r];
            }
        }

        //calculate he beta
        for(s = 0 ; s < K ; s++)
        {
            betasum[s]= 0.0;
            for( w = 0 ; w < contentLength; w++)
            {
                betaterm[s][w] = 0.0;
            }
        }

        for(s = 0 ; s < K ; s++)
        {
            for(i = 0 ; i < G.nvertices ; i++)
            {
                for(w= 0 ; w< G.vertex[i].hasContentLength ; w++)
                {
                    for( r= 0 ; r < K ; r++)
                    {
                        bterm = q[i][r]*t[i][r][s];
                         if(bterm < SMALL) bterm = SMALL;
                        betaterm[s][G.vertex[i].content[w]] += bterm;
                        betasum[s] +=  bterm *G.vertex[i].hasContentLength;
                    }
                }
            }
        }
        for(s = 0 ; s < K ; s++)
        {
            for( w = 0 ; w < contentLength; w++)
            {
                oldbeta[s][w] = beta[s][w];
                beta[s][w] = betaterm[s][w]/betasum[s];
                //  printf("%0.6f " ,beta[s][w]);
            }
            //     printf("\n");
        }
        maxInnerdelta = 0.0;
        //Find the largest change in any of t
        for (i = 0; i < G.nvertices; i++)
        {
            for (r = 0; r < K ; r++)
            {
                for(s = 0 ; s <K ; s++)
                {
                    delta = fabs(t[i][r][s]-oldt[i][r][s]);
                    if (delta>maxInnerdelta) maxInnerdelta = delta;
                }

            }
        }
        // Find the largest change in any of the eta's

        for (r=0; r<K; r++)
        {
            for (s=0; s<K; s++)
            {
                delta = fabs(eta[r][s]-oldeta[r][s]);
                if (delta>maxInnerdelta) maxInnerdelta = delta;
            }
        }
        // Find the largest change in any of the beta's
        for(s = 0 ; s < K ; s++)
        {
            for(w =0 ; w < contentLength; w++)
            {
                delta = fabs(beta[s][w]-oldbeta[s][w]);
                if (delta>maxInnerdelta) maxInnerdelta = delta;
            }
        }
      //   fprintf(stderr,"inner EM steps %i  %.6f\n ",innerStep,maxInnerdelta);

// Free space

        for (i = 0 ; i < G.nvertices ; i++)
        {

            for( r = 0 ; r < K ; r ++)
        { // printf("%.6f dgggggggggggdd ",tterm[i][r]);
                free(tterm[i][r]);
			}
             free(tterm[i]);
            
        }
        free(tterm);
       

		 for (i = 0 ; i < G.nvertices ; i++)
        {

         
            free(tsum[i]);
        }
      
        free(tsum);


        /*
                if (++innerStep>=INNEREM_MAXSTEP)
                {
        #ifdef NOCONVERGE
                    fprintf(stderr,"Solution failed to converge in %i INNER EM steps\n",
                            INNEREM_MAXSTEP);
        #endif
                    break;
                }
        */
    }
    while(++ innerStep < INNEREM_MAXSTEP );
    // while (maxInnerdelta > EM_ACC);

    // Calculate the expected log-likelihood
    L = 0.0 ;
    lterm = malloc(sizeof(double**)*G.nvertices);
    lsum=malloc(G.nvertices*sizeof(double*));
    for (i = 0 ; i < G.nvertices ; i++)
    {
        lsum[i] =malloc(K*sizeof(double));
        lterm[i] =malloc(K*sizeof(double*));
        for( r = 0 ; r < K ; r ++)
        {
            lsum[i][r] = 0.0;
            lterm[i][r] =malloc(K*sizeof(double));
            for(s = 0 ; s < K ; s++)
            {
                lterm[i][r][s] = 0.0;
            }
        }
    }
    for(i = 0 ; i < G.nvertices ; i++)
    {
        for(r = 0 ; r < K ; r++)
        {
            if(pi[r] < SMALL) pi[r] = SMALL;
            lsum[i][r] = log(pi[r]);
            for(j = 0 ; j < G.vertex[i].degree ; j++)
            {
                u = G.vertex[i].edge[j].target;
                if(theta[r][u] < SMALL) theta[r][u] = SMALL;
                lsum[i][r] += log(theta[r][u]);
            }
            for(s = 0 ; s <K ; s++)
            {
                for(w = 0 ; w < G.vertex[i].hasContentLength; w++)
                {
                    if(beta[s][G.vertex[i].content[w]] < SMALL) beta[s][G.vertex[i].content[w]] = SMALL;
                    lterm[i][r][s] += balance*log(beta[s][G.vertex[i].content[w]]);
                }
                if(t[i][r][s] < SMALL) t[i][r][s] = SMALL;
                if(eta[r][s] < SMALL) eta[r][s] =SMALL;
                lsum[i][r] += t[i][r][s]*(log(eta[r][s])+lterm[i][r][s]-log(t[i][r][s]));
            }
            if(q[i][r] < SMALL) q[i][r] = SMALL;
            lsum[i][r] -= log(q[i][r]);
            L += q[i][r] *lsum[i][r];
        }
    }

    // Free space
    for (i = 0 ; i < G.nvertices ; i++)
    {

        for( r = 0 ; r < K ; r ++)
        {
            free(oldt[i][r]);
        }
        free(oldt[i]);

    }
    free(oldt);

    for (i = 0 ; i < G.nvertices ; i++)
    {

        for( r = 0 ; r < K ; r ++)
        {
            free(qterm[i][r]);
        }
        free(qterm[i]);
        free(qsum[i]);
    }
    free(qterm);
    free(qsum);
    free(qallsum);


    for (i = 0 ; i < G.nvertices ; i++)
    {

        for( r = 0 ; r < K ; r ++)
        {
            free(lterm[i][r]);
        }
        free(lterm[i]);
        free(lsum[i]);
    }
    free(lterm);
    free(lsum);

    return L;
}


int main(int argc,char *argv[])
{

    int u,v,i,j,r,s,w,lg;
    int restart,outStep;
    double L,maxL,maxOutdelta;
    double twom,twok;
    double **maxq,maxeta[K][K],**maxbeta;
    double delta;
	 FILE *fr;
    // Initialize random number generator

    rng = gsl_rng_alloc(gsl_rng_mt19937);
    gsl_rng_set(rng,time(NULL));


    //Read the network and the content from stdin
#ifdef VERBOSE
		freopen("filename.txt", "a+", stdout);
    fprintf(stderr,"Reading network...\n");
#endif // VERBOSE
	fr = fopen("F:/data/rgnet.gml", "r");
    read_network(&G,fr);
    // printf("%i\n", G.vertex[0].hasContentLength);
   // contentLength = G.contentLength;

    //make sapce for maxq
    maxq = malloc(G.nvertices*sizeof(double*));
    for (u=0; u<G.nvertices; u++)
    {
        maxq[u] = malloc(K*sizeof(double));
    }
    //Make space for the maxbeta
    maxbeta = malloc(K*sizeof(double*)) ;  // topic-words parameters
    for(r = 0 ; r < K; r++)
    {
        maxbeta[r] = malloc(contentLength*sizeof(double));
    }
    //choose the number of restarts
    restart = 0 ;
    do
    {
        // Malloc space for q and maxq , and choose random initial values
        q = malloc(G.nvertices*sizeof(double*));
        for (u=0; u<G.nvertices; u++)
        {
            q[u] = malloc(K*sizeof(double));
             random_unity(K,q[u]);
        }

        // Malloc space for parameters pi and choose random initial values

        pi = malloc(K*sizeof(double));
        random_unity(K,pi);

        // Choose random values for the theta,
        theta = malloc(K*sizeof(double*));
        oldtheta = malloc(K*sizeof(double*));

        for (r=0; r<K; r++)
        {
            theta[r] = malloc(G.nvertices*sizeof(double));
            oldtheta[r] = malloc(G.nvertices*sizeof(double));

           random_unity(G.nvertices,theta[r]);

        }

        //Choose random values for the etha

        for(r = 0 ; r < K ; r++)
        {
            random_unity(K,eta[r]);
        }

        //Choose random values for the beta
        beta = malloc(K*sizeof(double*)) ;  // topic-words parameters

        for(r = 0 ; r < K; r++)
        {
            beta[r] = malloc(contentLength*sizeof(double));
            random_unity(contentLength,beta[r]);
        }

        //Choose random values for the t
        t = malloc(G.nvertices*sizeof(double**));
        for (u = 0; u < G.nvertices; u++)
        {
            t[u] = malloc(K*sizeof(double*));
            for (r = 0; r < K ; r++)
            {
                t[u][r] = malloc(K*sizeof(double));
                random_unity(K,t[u][r]);
            }
        }

// out EM loop
#ifdef VERBOSE
	
        fprintf(stderr,"Starting EM algorithm...\n");
#endif
        outStep = 0;
        do
        {
            // Calculate the new values of the parameters
            L = params();

            // Find the largest change in any of the theta's
            maxOutdelta = 0.0;
            for (r=0; r<K; r++)
            {
                for (j=0; j<G.nvertices; j++)
                {
                    delta = fabs(theta[r][j] - oldtheta[r][j]);
                    if (delta>maxOutdelta) maxOutdelta = delta;
                }
            }
            // Find the largest change in any of the pi's
            for(r= 0 ; r < K ; r++)
            {
                delta = fabs(pi[r] - oldpi[r]);
                if (delta>maxOutdelta) maxOutdelta = delta;
            }

            // Print out new values of the parameters
#ifdef VERBOSE
            fprintf(stderr,"out EM step %i, max change = %g\n",outStep,maxOutdelta);
            fprintf(stderr,"Log-likelihood = %.10g\n",L);
       //     fprintf(stderr,"restart = %i\n",restart);
          //  fprintf(stderr,"beta =\n");
           /* for (r=0; r<K; r++)
            {
                fprintf(stderr," %.6f",pi[r]);
                fprintf(stderr,"\n");
            }*/

#endif

        }
        while (++outStep<OUTEM_MAXSTEP);

#ifdef VERBOSE
        fprintf(stderr,"Log-likelihood = %g\n\n",L);
#endif

        if(restart == 0)
        {
            maxL = L ;
            for (u=0; u<G.nvertices; u++)
            {
                for (r=0; r<K; r++)
                {
                    maxq[u][r] = q[u][r];
                }
            }
            for(r= 0 ; r < K ; r++)
            {
                for(s = 0 ; s <K ; s++)
                {
                    maxeta[r][s] = eta[r][s];
                }
            }
            for(s = 0 ; s < K ; s++)
            {
                for(w = 0 ; w < contentLength ; w++)
                {
                    maxbeta[s][w] = beta[s][w];
                }
            }
        }
        if(L > maxL )
        {
            maxL = L;
            for (u=0; u<G.nvertices; u++)
            {
                for (r=0; r<K; r++)
                {
                    maxq[u][r] = q[u][r];
                }
            }
            for(r= 0 ; r < K ; r++)
            {
                for(s = 0 ; s <K ; s++)
                {
                    maxeta[r][s] = eta[r][s];
                }
            }
            for(s = 0 ; s < K ; s++)
            {
                for(w = 0 ; w < contentLength ; w++)
                {
                    maxbeta[s][w] = beta[s][w];
                }
            }
        }
    }
    while(++restart < RESTART);

    // Output the results

    for (u=0; u<G.nvertices; u++)
    {
        for (r=0; r<K; r++) 
		{
			
			fprintf(stdout,"maxq  %.6f",maxq[u][r]);
		}
		printf("\n");
    }


    for(r= 0 ; r < K ; r++)
    {
        for(s = 0 ; s <K ; s++)
        {
            fprintf(stdout,"alpha %.6f",maxeta[r][s]);
        }
        printf("\n");
    }
   /* for(s = 0 ; s < K ; s++)
    {
        for(w = 0 ; w < contentLength ; w++)
        {
            fprintf(stdout,"maxphi %.6f",maxbeta[s][w]);
        }
        printf("\n");
    }*/

/*
                fclose(stdin);
                fclose(stdout);
        }

*/
    return 0;
	system("pause");
}

