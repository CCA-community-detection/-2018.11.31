// Header file for VERTEX, EDGE, and NETWORK data structures
//

#ifndef _NETWORK_H
#define _NETWORK_H

typedef struct {
  int target;        // Index in the vertex[] array of neighboring vertex.
                     // (Note that this is not necessarily equal to the GML
                     // ID of the neighbor if IDs are nonconsecutive or do
                     // not start at zero.)
  double weight;     // Weight of edge.  1 if no weight is specified.
} EDGE;
typedef struct {
  int rtarget;      
  double rweight;    
} RELATION;

typedef struct {
  int id;            // GML ID number of vertex
  int degree;        // Degree of vertex (out-degree for directed nets)
  int *content;       // GML label of vertex.  NULL if no label specified
  int hasContentLength;
  EDGE *edge;          // Array of EDGE structs, one for each neighbor
  RELATION *relation;
} VERTEX;

typedef struct {
  int nvertices;     // Number of vertices in network
  VERTEX *vertex;    // Array of VERTEX structs, one for each vertex
  int contentLength;
} NETWORK;

#endif
